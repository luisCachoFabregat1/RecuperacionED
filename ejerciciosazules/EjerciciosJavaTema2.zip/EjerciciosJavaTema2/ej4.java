package EjerciciosJavaTema2;

//suma de los primeros 100 num
public class ej4 {

	public static void main(String[] args) {
		int suma = 0;
		for (int i = 1; i <= 100; i++) {
			suma += i;
		}
		System.out.println(suma);
	}

}
